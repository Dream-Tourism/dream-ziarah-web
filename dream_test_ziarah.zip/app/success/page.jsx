import PaymentSuccess from "@/components/paymentSuccess/paymentsuccess";
import React from "react";

const page = () => {
  return (
    <div>
      <PaymentSuccess />
    </div>
  );
};

export default page;
